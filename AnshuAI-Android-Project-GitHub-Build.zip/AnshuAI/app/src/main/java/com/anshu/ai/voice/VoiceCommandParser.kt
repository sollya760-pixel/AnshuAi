package com.anshu.ai.voice

/**
 * Recognizes natural voice commands in both English and Hindi.
 */
sealed class VoiceCommand {
    data class CreateNote(val initialText: String = "") : VoiceCommand()
    data object SaveNote : VoiceCommand()
    data object ReadNotes : VoiceCommand()
    data class DictationText(val text: String) : VoiceCommand()
}

object VoiceCommandParser {

    private val createTriggers = listOf(
        "anshu create a note",
        "anshu, create a note",
        "anshu create note",
        "create a note",
        "new note",
        "अंशु नोट बनाओ",
        "अंशु, नोट बनाओ",
        "नया नोट बनाओ",
        "नोट बनाओ"
    )

    private val saveTriggers = listOf(
        "save this note",
        "anshu save this note",
        "save note",
        "नोट सेव करो",
        "यह नोट सेव करो",
        "सेव करो"
    )

    private val readTriggers = listOf(
        "read my notes",
        "anshu read my notes",
        "read all notes",
        "मेरे नोट्स पढ़ो",
        "नोट्स पढ़ो",
        "मेरे नोट सुनाओ"
    )

    fun parse(rawSpeech: String): VoiceCommand {
        val cleaned = rawSpeech.trim()
        val normalized = cleaned.lowercase()
            .replace(",", " ")
            .replace("।", " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // 1. Check "Save this note"
        if (saveTriggers.any { normalized == it || normalized.endsWith(it) }) {
            return VoiceCommand.SaveNote
        }

        // 2. Check "Read my notes"
        if (readTriggers.any { normalized.contains(it) }) {
            return VoiceCommand.ReadNotes
        }

        // 3. Check "Anshu, create a note ..." (supports inline dictation right after the command)
        for (trigger in createTriggers) {
            if (normalized.startsWith(trigger)) {
                val remainder = cleaned
                    .replaceFirst(Regex("(?i)^.*?${Regex.escape(trigger)}[,:.\\s-]*"), "")
                    .trim()
                return VoiceCommand.CreateNote(initialText = remainder)
            }
        }

        // 4. Otherwise treat spoken words as editable note text
        return VoiceCommand.DictationText(cleaned)
    }
}
