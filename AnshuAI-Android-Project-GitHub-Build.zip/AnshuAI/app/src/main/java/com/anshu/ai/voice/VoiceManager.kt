package com.anshu.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Beginner-friendly wrapper around Android's built-in SpeechRecognizer and TextToSpeech.
 * Completely free — uses Android's native speech services with zero paid API keys.
 */
class VoiceManager(
    private val context: Context,
    private val onPartialResult: (String) -> Unit,
    private val onFinalResult: (String) -> Unit,
    private val onListeningChanged: (Boolean) -> Unit,
    private val onSpeakingChanged: (Boolean) -> Unit,
    private val onError: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            isTtsReady = (status == TextToSpeech.SUCCESS)
            if (isTtsReady) {
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }
                })
            }
        }
    }

    fun startListening(languageCode: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Voice recognition is not available on this device. Please install Google Speech Services.")
            return
        }

        // Destroy any previous recognizer instance before starting a new session
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    onListeningChanged(true)
                }

                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit

                override fun onEndOfSpeech() {
                    onListeningChanged(false)
                }

                override fun onError(error: Int) {
                    onListeningChanged(false)
                    onError(mapSpeechError(error))
                }

                override fun onResults(results: Bundle?) {
                    onListeningChanged(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val bestMatch = matches?.firstOrNull().orEmpty()
                    if (bestMatch.isNotBlank()) {
                        onFinalResult(bestMatch)
                    } else {
                        onError("Could not hear anything clearly. Please tap the mic and try again.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotBlank()) {
                        onPartialResult(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode) // "hi-IN" or "en-IN"
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: SecurityException) {
            onListeningChanged(false)
            onError("Microphone permission is required. Please allow microphone access in Settings.")
        } catch (e: Exception) {
            onListeningChanged(false)
            onError("Could not start microphone: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        onListeningChanged(false)
    }

    fun speak(text: String, preferredLanguageCode: String) {
        if (!isTtsReady || text.isBlank()) {
            if (!isTtsReady) {
                onError("Text-to-speech engine is still warming up. Please try again in a moment.")
            }
            return
        }

        // Automatically choose Hindi voice if Devanagari characters are present
        val containsHindi = text.any { it in '\u0900'..'\u097F' }
        val locale = if (containsHindi || preferredLanguageCode.startsWith("hi")) {
            Locale("hi", "IN")
        } else {
            Locale("en", "IN")
        }

        val result = textToSpeech?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            textToSpeech?.language = Locale.US
        }

        textToSpeech?.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "anshu_tts_${System.currentTimeMillis()}"
        )
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        onSpeakingChanged(false)
    }

    fun release() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }

    private fun mapSpeechError(errorCode: Int): String = when (errorCode) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Check if another app is using the microphone."
        SpeechRecognizer.ERROR_CLIENT -> "Voice recognition stopped."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied. Please grant permission to record voice notes."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Network unavailable for speech recognition. Check your internet or enable offline speech pack."
        SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please speak clearly near the microphone."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy. Please wait a second and try again."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out because no voice was detected."
        else -> "Voice recognition failed (code $errorCode). Please try again."
    }
}
