package com.anshu.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.anshu.ai.data.AnshuDatabase
import com.anshu.ai.data.NoteEntity
import com.anshu.ai.voice.VoiceCommand
import com.anshu.ai.voice.VoiceCommandParser
import com.anshu.ai.voice.VoiceManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AnshuUiState(
    val selectedLanguage: String = "en-IN", // "en-IN" (English) or "hi-IN" (Hindi)
    val searchQuery: String = "",
    val draftNoteId: Long? = null,
    val draftTitle: String = "",
    val draftContent: String = "",
    val partialSpeech: String = "",
    val isComposerVisible: Boolean = false,
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val activeSpeakingNoteId: Long? = null,
    val notePendingDelete: NoteEntity? = null,
    val errorMessage: String? = null,
    val statusMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class AnshuViewModel(application: Application) : AndroidViewModel(application) {

    private val noteDao = AnshuDatabase.getInstance(application).noteDao()

    private val _uiState = MutableStateFlow(AnshuUiState())
    val uiState: StateFlow<AnshuUiState> = _uiState.asStateFlow()

    private val searchFlow = MutableStateFlow("")

    val notes: StateFlow<List<NoteEntity>> = searchFlow
        .flatMapLatest { query ->
            if (query.isBlank()) noteDao.getAllNotes()
            else noteDao.searchNotes(query.trim())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val voiceManager = VoiceManager(
        context = application,
        onPartialResult = { partial ->
            _uiState.update { it.copy(partialSpeech = partial, errorMessage = null) }
        },
        onFinalResult = { spokenText ->
            handleSpokenResult(spokenText)
        },
        onListeningChanged = { listening ->
            _uiState.update { it.copy(isListening = listening) }
        },
        onSpeakingChanged = { speaking ->
            _uiState.update {
                it.copy(
                    isSpeaking = speaking,
                    activeSpeakingNoteId = if (speaking) it.activeSpeakingNoteId else null
                )
            }
        },
        onError = { error ->
            _uiState.update { it.copy(errorMessage = error, partialSpeech = "") }
        }
    )

    fun setLanguage(languageCode: String) {
        _uiState.update { it.copy(selectedLanguage = languageCode, errorMessage = null) }
    }

    fun onSearchQueryChanged(query: String) {
        searchFlow.value = query
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun openNewNoteComposer(initialText: String = "") {
        _uiState.update {
            it.copy(
                isComposerVisible = true,
                draftNoteId = null,
                draftTitle = "",
                draftContent = initialText,
                partialSpeech = "",
                errorMessage = null
            )
        }
    }

    fun openEditNote(note: NoteEntity) {
        _uiState.update {
            it.copy(
                isComposerVisible = true,
                draftNoteId = note.id,
                draftTitle = note.title,
                draftContent = note.content,
                selectedLanguage = note.languageCode,
                partialSpeech = "",
                errorMessage = null
            )
        }
    }

    fun closeComposer() {
        _uiState.update {
            it.copy(
                isComposerVisible = false,
                draftNoteId = null,
                draftTitle = "",
                draftContent = "",
                partialSpeech = ""
            )
        }
    }

    fun onDraftTitleChanged(title: String) {
        _uiState.update { it.copy(draftTitle = title) }
    }

    fun onDraftContentChanged(content: String) {
        _uiState.update { it.copy(draftContent = content) }
    }

    fun saveDraftNote() {
        val state = _uiState.value
        val content = state.draftContent.trim()
        val title = state.draftTitle.trim().ifEmpty {
            content.lineSequence().firstOrNull()?.take(40)?.ifBlank { "Voice Note" } ?: "Voice Note"
        }

        if (content.isBlank() && state.draftTitle.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Cannot save an empty note. Speak or type something first.") }
            return
        }

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            if (state.draftNoteId != null) {
                val existing = notes.value.find { it.id == state.draftNoteId }
                noteDao.updateNote(
                    NoteEntity(
                        id = state.draftNoteId,
                        title = title,
                        content = content,
                        languageCode = state.selectedLanguage,
                        createdAt = existing?.createdAt ?: now,
                        updatedAt = now
                    )
                )
            } else {
                noteDao.insertNote(
                    NoteEntity(
                        title = title,
                        content = content,
                        languageCode = state.selectedLanguage,
                        createdAt = now,
                        updatedAt = now
                    )
                )
            }

            _uiState.update {
                it.copy(
                    isComposerVisible = false,
                    draftNoteId = null,
                    draftTitle = "",
                    draftContent = "",
                    partialSpeech = "",
                    statusMessage = "Note saved locally."
                )
            }
        }
    }

    fun requestDeleteNote(note: NoteEntity) {
        _uiState.update { it.copy(notePendingDelete = note) }
    }

    fun cancelDeleteNote() {
        _uiState.update { it.copy(notePendingDelete = null) }
    }

    fun confirmDeleteNote() {
        val note = _uiState.value.notePendingDelete ?: return
        viewModelScope.launch {
            noteDao.deleteNote(note)
            if (_uiState.value.activeSpeakingNoteId == note.id) {
                voiceManager.stopSpeaking()
            }
            _uiState.update {
                it.copy(
                    notePendingDelete = null,
                    statusMessage = "Note deleted."
                )
            }
        }
    }

    fun toggleListening() {
        if (_uiState.value.isListening) {
            voiceManager.stopListening()
        } else {
            _uiState.update { it.copy(errorMessage = null, statusMessage = null, partialSpeech = "") }
            voiceManager.startListening(_uiState.value.selectedLanguage)
        }
    }

    fun readNoteAloud(note: NoteEntity) {
        if (_uiState.value.isSpeaking && _uiState.value.activeSpeakingNoteId == note.id) {
            voiceManager.stopSpeaking()
            return
        }
        _uiState.update { it.copy(activeSpeakingNoteId = note.id, errorMessage = null) }
        voiceManager.speak("${note.title}. ${note.content}", note.languageCode)
    }

    fun readAllNotesAloud() {
        val currentNotes = notes.value
        if (currentNotes.isEmpty()) {
            val emptyPrompt = if (_uiState.value.selectedLanguage.startsWith("hi")) {
                "अभी कोई नोट सेव नहीं है।"
            } else {
                "You do not have any saved notes yet."
            }
            voiceManager.speak(emptyPrompt, _uiState.value.selectedLanguage)
            return
        }

        val combined = currentNotes.take(5).joinToString(separator = ". ") { note ->
            "${note.title}: ${note.content}"
        }
        _uiState.update { it.copy(activeSpeakingNoteId = -1L) }
        voiceManager.speak(combined, _uiState.value.selectedLanguage)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun reportError(message: String) {
        _uiState.update { it.copy(errorMessage = message) }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, statusMessage = null) }
    }

    private fun handleSpokenResult(spokenText: String) {
        when (val command = VoiceCommandParser.parse(spokenText)) {
            is VoiceCommand.CreateNote -> {
                openNewNoteComposer(command.initialText)
                val confirmation = if (_uiState.value.selectedLanguage.startsWith("hi")) {
                    "नया नोट तैयार है। कृपया बोलें।"
                } else {
                    "Ready. Creating a new note."
                }
                voiceManager.speak(confirmation, _uiState.value.selectedLanguage)
            }

            is VoiceCommand.SaveNote -> {
                if (_uiState.value.isComposerVisible &&
                    (_uiState.value.draftContent.isNotBlank() || _uiState.value.draftTitle.isNotBlank())
                ) {
                    saveDraftNote()
                    val savedMsg = if (_uiState.value.selectedLanguage.startsWith("hi")) {
                        "नोट सेव हो गया है।"
                    } else {
                        "Note saved."
                    }
                    voiceManager.speak(savedMsg, _uiState.value.selectedLanguage)
                } else {
                    _uiState.update {
                        it.copy(errorMessage = "Open or dictate a note before saying 'Save this note'.")
                    }
                }
            }

            is VoiceCommand.ReadNotes -> {
                readAllNotesAloud()
            }

            is VoiceCommand.DictationText -> {
                _uiState.update { current ->
                    val updatedBody = if (current.draftContent.isBlank()) {
                        command.text
                    } else {
                        "${current.draftContent.trimEnd()} ${command.text}"
                    }
                    current.copy(
                        isComposerVisible = true,
                        draftContent = updatedBody,
                        partialSpeech = "",
                        statusMessage = "Speech added to editable note."
                    )
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
