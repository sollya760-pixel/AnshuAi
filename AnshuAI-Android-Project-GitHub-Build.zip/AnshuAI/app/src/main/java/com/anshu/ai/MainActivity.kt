package com.anshu.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.anshu.ai.data.NoteEntity
import com.anshu.ai.ui.AnshuViewModel
import com.anshu.ai.ui.theme.AnshuAiTheme
import com.anshu.ai.ui.theme.CyberCyan
import com.anshu.ai.ui.theme.DangerCrimson
import com.anshu.ai.ui.theme.DeepSpaceBg
import com.anshu.ai.ui.theme.ElectricBlue
import com.anshu.ai.ui.theme.ElevatedCardSurface
import com.anshu.ai.ui.theme.MidnightSurface
import com.anshu.ai.ui.theme.RoyalPurple
import com.anshu.ai.ui.theme.SoftBorder
import com.anshu.ai.ui.theme.TextPrimary
import com.anshu.ai.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AnshuAiTheme {
                AnshuAiApp()
            }
        }
    }
}

@Composable
fun AnshuAiApp(viewModel: AnshuViewModel = viewModel()) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val notes by viewModel.notes.collectAsStateWithLifecycle()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.toggleListening()
        } else {
            viewModel.reportError("Microphone permission denied. Please grant access to record voice notes.")
        }
    }

    fun onMicPressed() {
        if (hasMicPermission) {
            viewModel.toggleListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        containerColor = DeepSpaceBg,
        bottomBar = {
            VoiceMicDock(
                isListening = uiState.isListening,
                partialSpeech = uiState.partialSpeech,
                selectedLanguage = uiState.selectedLanguage,
                onMicClick = { onMicPressed() },
                onNewNoteClick = { viewModel.openNewNoteComposer() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DeepSpaceBg, Color(0xFF0A0F28), DeepSpaceBg)
                    )
                )
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // Top App Header & Language Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ANSHU AI",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Hindi & English Voice Notes",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LanguageChip(
                        label = "EN",
                        selected = uiState.selectedLanguage == "en-IN",
                        onClick = { viewModel.setLanguage("en-IN") }
                    )
                    LanguageChip(
                        label = "हिंदी",
                        selected = uiState.selectedLanguage == "hi-IN",
                        onClick = { viewModel.setLanguage("hi-IN") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Microphone Permission Banner if not yet granted
            AnimatedVisibility(visible = !hasMicPermission) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1B4B)),
                    border = BorderStroke(1.dp, RoyalPurple),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Microphone access is needed for voice notes.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }) {
                            Text("Allow", color = CyberCyan)
                        }
                    }
                }
            }

            // Error / Status Banner
            AnimatedVisibility(visible = uiState.errorMessage != null || uiState.statusMessage != null) {
                val isError = uiState.errorMessage != null
                val bannerText = uiState.errorMessage ?: uiState.statusMessage.orEmpty()
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isError) Color(0xFF311020) else Color(0xFF10243E)
                    ),
                    border = BorderStroke(1.dp, if (isError) DangerCrimson else ElectricBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = bannerText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.clearMessages() }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Dismiss", tint = TextSecondary)
                        }
                    }
                }
            }

            // Editable Voice-to-Text Composer
            AnimatedVisibility(visible = uiState.isComposerVisible) {
                NoteComposerCard(
                    title = uiState.draftTitle,
                    content = uiState.draftContent,
                    isEditing = uiState.draftNoteId != null,
                    onTitleChange = viewModel::onDraftTitleChanged,
                    onContentChange = viewModel::onDraftContentChanged,
                    onSave = viewModel::saveDraftNote,
                    onCancel = viewModel::closeComposer
                )
            }

            // Search Bar + Read All Notes Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = viewModel::onSearchQueryChanged,
                    placeholder = { Text("Search notes...", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Rounded.Search, contentDescription = null, tint = CyberCyan)
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = SoftBorder,
                        focusedContainerColor = MidnightSurface,
                        unfocusedContainerColor = MidnightSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )

                OutlinedButton(
                    onClick = {
                        if (uiState.isSpeaking) viewModel.stopSpeaking()
                        else viewModel.readAllNotesAloud()
                    },
                    border = BorderStroke(1.dp, RoyalPurple),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp)
                ) {
                    Icon(
                        imageVector = if (uiState.isSpeaking) Icons.Rounded.Stop else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Read all notes",
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Saved Notes List
            if (notes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (uiState.searchQuery.isBlank()) "No notes saved yet" else "No matching notes",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap the mic and say \"Anshu, create a note\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(notes, key = { it.id }) { note ->
                        SavedNoteCard(
                            note = note,
                            isSpeakingThis = uiState.isSpeaking && uiState.activeSpeakingNoteId == note.id,
                            onReadAloud = { viewModel.readNoteAloud(note) },
                            onEdit = { viewModel.openEditNote(note) },
                            onDelete = { viewModel.requestDeleteNote(note) }
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    val noteToDelete = uiState.notePendingDelete
    if (noteToDelete != null) {
        AlertDialog(
            onDismissRequest = { viewModel.cancelDeleteNote() },
            containerColor = ElevatedCardSurface,
            title = { Text("Delete Note?", color = TextPrimary) },
            text = {
                Text(
                    "Are you sure you want to delete \"${noteToDelete.title}\"? This cannot be undone.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmDeleteNote() },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerCrimson)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.cancelDeleteNote() }) {
                    Text("Cancel", color = TextPrimary)
                }
            }
        )
    }
}

@Composable
private fun LanguageChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontWeight = FontWeight.SemiBold) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = RoyalPurple,
            selectedLabelColor = Color.White,
            containerColor = MidnightSurface,
            labelColor = TextSecondary
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = SoftBorder,
            selectedBorderColor = CyberCyan
        )
    )
}

@Composable
private fun NoteComposerCard(
    title: String,
    content: String,
    isEditing: Boolean,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ElevatedCardSurface),
        border = BorderStroke(1.dp, ElectricBlue),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = if (isEditing) "Edit Note" else "New Voice Note",
                style = MaterialTheme.typography.titleMedium,
                color = CyberCyan
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                label = { Text("Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = content,
                onValueChange = onContentChange,
                label = { Text("Note text (speak or edit)") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel", color = TextSecondary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) {
                    Text("Save Note")
                }
            }
        }
    }
}

@Composable
private fun SavedNoteCard(
    note: NoteEntity,
    isSpeakingThis: Boolean,
    onReadAloud: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedDate = remember(note.updatedAt) {
        SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.getDefault()).format(Date(note.updatedAt))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MidnightSurface),
        border = BorderStroke(1.dp, SoftBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = if (note.languageCode.startsWith("hi")) "HI" else "EN",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyberCyan
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = formattedDate,
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = note.content,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD5E1)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onReadAloud) {
                    Icon(
                        imageVector = if (isSpeakingThis) Icons.Rounded.Stop else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = if (isSpeakingThis) "Stop reading" else "Read note aloud",
                        tint = CyberCyan
                    )
                }
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "Edit note",
                        tint = ElectricBlue
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete note",
                        tint = DangerCrimson
                    )
                }
            }
        }
    }
}

@Composable
private fun VoiceMicDock(
    isListening: Boolean,
    partialSpeech: String,
    selectedLanguage: String,
    onMicClick: () -> Unit,
    onNewNoteClick: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.12f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        color = Color(0xFF090E23),
        border = BorderStroke(1.dp, SoftBorder),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isListening || partialSpeech.isNotBlank()) {
                Text(
                    text = partialSpeech.ifBlank {
                        if (selectedLanguage.startsWith("hi")) "सुन रहा हूँ... बोलें" else "Listening... Speak now"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberCyan,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = onNewNoteClick,
                    border = BorderStroke(1.dp, SoftBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, tint = TextPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Type", color = TextPrimary)
                }

                // Large Futuristic Blue & Purple Microphone Button
                Surface(
                    onClick = onMicClick,
                    shape = CircleShape,
                    color = Color.Transparent,
                    modifier = Modifier
                        .size(76.dp)
                        .scale(pulseScale)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = if (isListening) {
                                        listOf(DangerCrimson, RoyalPurple)
                                    } else {
                                        listOf(ElectricBlue, RoyalPurple)
                                    }
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                            contentDescription = "Voice Microphone",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }

                Text(
                    text = if (selectedLanguage.startsWith("hi")) "हिंदी" else "English",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
        }
    }
}
