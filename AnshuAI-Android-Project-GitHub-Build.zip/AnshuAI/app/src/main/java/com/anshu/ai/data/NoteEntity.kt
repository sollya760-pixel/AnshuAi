package com.anshu.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a single note stored locally on the phone using Room (SQLite).
 * Notes stay saved even after closing or restarting the app.
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val content: String,
    val languageCode: String = "en-IN", // "hi-IN" for Hindi or "en-IN" for English
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
