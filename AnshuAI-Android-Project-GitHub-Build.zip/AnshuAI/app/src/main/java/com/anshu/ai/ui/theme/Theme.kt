package com.anshu.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Futuristic Blue & Purple Palette for ANSHU AI
val DeepSpaceBg = Color(0xFF060919)
val MidnightSurface = Color(0xFF0E142D)
val ElevatedCardSurface = Color(0xFF151E42)
val ElectricBlue = Color(0xFF3B82F6)
val CyberCyan = Color(0xFF38BDF8)
val RoyalPurple = Color(0xFF8B5CF6)
val SoftBorder = Color(0xFF263366)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val DangerCrimson = Color(0xFFEF4444)

private val AnshuDarkColors = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    secondary = RoyalPurple,
    onSecondary = Color.White,
    tertiary = CyberCyan,
    background = DeepSpaceBg,
    onBackground = TextPrimary,
    surface = MidnightSurface,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = SoftBorder,
    error = DangerCrimson
)

private val AnshuTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 24.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        color = TextPrimary
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = TextSecondary
    )
)

@Composable
fun AnshuAiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AnshuDarkColors,
        typography = AnshuTypography,
        content = content
    )
}
