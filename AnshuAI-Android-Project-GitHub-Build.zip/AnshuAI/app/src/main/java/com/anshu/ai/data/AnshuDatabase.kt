package com.anshu.ai.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Local SQLite database powered by Room.
 * Uses a thread-safe singleton so only one database connection is created.
 */
@Database(entities = [NoteEntity::class], version = 1, exportSchema = false)
abstract class AnshuDatabase : RoomDatabase() {

    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile
        private var INSTANCE: AnshuDatabase? = null

        fun getInstance(context: Context): AnshuDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AnshuDatabase::class.java,
                    "anshu_ai_notes.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
